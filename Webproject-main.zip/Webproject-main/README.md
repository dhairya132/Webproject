# Webproject
I used a simple html and css code to build a traveling website. It's simple and I really enjoyed building it.
